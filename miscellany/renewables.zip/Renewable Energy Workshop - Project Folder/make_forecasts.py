'''
make_forecast module uses the geometric random walk with drift model assuming
Moore's Law to forecast future energy Consumption/Generation

R Maria del Rio Chanona, Oxford, 2017
'''
import pandas as pd
import numpy as np
import glob
from matplotlib import pylab as plt

results_path = "results/forecast/"

def mu_k_hat(quantity):
    '''Computes mean and standard deviation of the log of data
    Args:
        quantity(list): list of data
    Returns:
        mu (float): mean
        np.sqrt(k)(float): standard deviation
    '''
    log_prices = np.log(quantity)
    m = len(quantity) - 1 #since the actual data points are differences
    k = 0
    mu = float(log_prices[-1] - log_prices[0])/m
    for i in range(m):
        k += (log_prices[i + 1] - log_prices[i] - mu)**2
    k = k/float(m - 1)
    return mu, np.sqrt(k)

def save_mu_k_and_forecast(year_make_forecast, df, year_end_forecast=2015, \
                           year_data_starts=2000, file_name="EPS_Cap", \
                           save_path=results_path):
    '''For a given year makes the geometric random walk with drift forcast
    considering Moore's Law. Results are the paremeters Mu and K, and the
    forecasts for the following years. Everything is saved in csv file.
    Args:
        year_of_forecast(int): year forecast would be made
        df(DataFrame): pandas dataframe with the historical data
        year_end_forecat(int): until which year to forecast
        year_data_starts(int): first year of data
        file_name (str): part of the file name to which the results are exported
        save_path(str): folder path to which results are exported
    Returns:
        None
    '''
    m = year_make_forecast - year_data_starts
    last_data_point = year_make_forecast
    new_df = df[[i for i in range(year_data_starts, last_data_point + 1)]]
    #+1 is to include last_data_point
    data_points = len([i for i in range(year_data_starts, last_data_point + 1)])
    print("data start ", year_data_starts)
    print("data end ", last_data_point + 1)

    print(save_path + file_name + "_forecast_" + str(year_make_forecast) + "_M"\
          + str(m) +".csv")
    f_forecast = open(save_path + file_name + "_forecast_" + \
                 str(year_make_forecast) + "_M" + str(m) + ".csv","w")
    f_mu = open(save_path + file_name + "_Mu_" + str(year_make_forecast) + \
            "_M" + str(m) + ".csv" ,"w")
    f_k = open(save_path + file_name + "_K_" + str(year_make_forecast) + \
            "_M" + str(m) + ".csv" ,"w")

    for name in new_df.index:
        f_forecast.write("," + name)
        f_mu.write(name + ",")
        f_k.write(name + ",")

    f_forecast.write("\n")
    f_mu.write("\n")
    f_k.write("\n")

    for name in new_df.index: #Start forecasting and writing data
        quantity = list(new_df.loc[name])
        mu, k = mu_k_hat(quantity)
        f_mu.write(str(mu) + ",")
        f_k.write(str(k) + ",")

        if name == "Solar Photovoltaic":
            print(name, " ", k)
            print("data points = ", quantity)

    years_to_forecast = range(last_data_point, year_end_forecast + 1)
    #Note tau = 0 is included, to exclude to +1 in first part
    #+1 to include year_end_forecast in the list

    for y in years_to_forecast:
        f_forecast.write(str(y))
        for name in new_df.index: #iterate over each technology name
            f_forecast.write(",")
            quantity = list(new_df.loc[name])
            mu, k = mu_k_hat(quantity)
            starting_value = df[last_data_point].loc[name] #Start form our last
            # data point
            forecast_value = np.log(starting_value) + mu * (y - last_data_point)
            f_forecast.write(str(np.exp(forecast_value)) )
            #Forecast for real value, not log value

        f_forecast.write("\n")

    f_mu.close()
    f_k.close()
    f_forecast.close()

###############################################################################
#The plot function
###############################################################################

def plot_forecasts(name, df_hist, df_expert, df_grwd, m, \
                  fig_forecast_path = "fig/forecast/", f_name = "_Both", \
                  source = "EPS_Cap", end_comparison = 2015):
    '''Plots the expert and GRWD forecast with the real outcome in log
    Args:
        name(str): technology for which to do the plot
        df_hist(DataFrame): pandas dataframe with historical data
        df_expert(list): list of pandas dataframes, each with the expert
                        forecast of a given year
        df_expert(list): list of pandas dataframes, each with the GRWD
                        forecast of a given M
        m(int): number of previous data of differences
        fig_error_path(str): path to export figure
        f_name(str): string to save file
        source(str): string to save plot
        end_comparison(int): year to end comparison
    Returns:
        None. Does a plot.
        '''
    n_points = len(df_grwd)
    plt.plot(np.log(df_hist[name]), "o-", label = "Real")
    for i in range(n_points):
        if i == 0:
            plt.plot(np.log(df_expert[i + m][name].loc[:2015]), "g*-", \
                    alpha = 0.5, label = "Expert")
            plt.plot(np.log(df_grwd[i][name]), "r^-", alpha = 0.5, \
                    label = "GRWD")
            plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
        else:
            plt.plot(np.log(df_expert[i + m][name].loc[:end_comparison]), \
                    "g*-", alpha = 0.5)
            plt.plot(np.log(df_grwd[i][name]), "r^-", alpha = 0.5)

    plt.xlabel("Year")
    plt.ylabel("log(quantity)")
    plt.title(source + " " + name +" forecasts for M = "+ str(m) )
    plt.savefig(fig_forecast_path + source + "_" + name + f_name + "_M" + str(m) +".png",bbox_inches='tight')
    plt.show()
