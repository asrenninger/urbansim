'''
make_errors models defines the functions to compute error of expert forecasts
uses pand geometric random walk with drift (GRWD). Errors are in percentage
but also using the normalization given by the GRWD.

remember to update below

Note: we count "past forecasts" as forecasts although forecast horizon
is not define. Example, in year 2004 the values of 2003 are not actual
the actual mesurements but a forecast in some sense. In this case we only
normalise by standard deviation. I think we should actually call this
 measurment errors.

R Maria del Rio Chanona, Oxford, 2017
'''
import glob
import copy
from matplotlib import pylab as plt
import pandas as pd
import numpy as np

def make_index_name_dict(year_to_start_comparison, year_end):
    '''makes an index (int) to year (int) dictionary, starting from the year to
    start making the comparisons
    '''
    index_name_dict = {}
    y0 = year_to_start_comparison
    for i in range(year_end - year_to_start_comparison):
        index_name_dict[i] = y0
        y0 += 1

    return index_name_dict

def normalise_error(e, k, tau, m):
    '''Normalises an error with the GRWD norm. Note that it allows for negative
    time horizons, in which case it only normalises by standard deviation.
    Args:
        e(float): error to normalise
        k(float): standar deviation of the data
        tau(int): forecast horizon
        m(int): number of points used for the forecast
    Returns:
        norm_e(float): error normalised with GRWD norm
    '''
    if tau <= 0:
        norm_e = e/k
    else:
        norm_e = e/(k * np.sqrt(tau + tau**2/m)  )
    return norm_e

def error_percent(df_hist, df_forecast, end_comparison=2017):
    '''Computes the percentage error between the two dataframes for each year
    and technology.
    Args:
        df_hist(DataFrame): data frame of true outcomes
        df_forecast(DataFrame): data frame of the forecasts for a given year
        end_comparison(int): year for which to stop comparing the data frames
    Returns:
        df_(DataFrame):data frame with the percentage error made for each year
        of prediction, starting for tau = 0.
    '''
    year_make_forecast = df_forecast.index[0]
    names_list = df_forecast.columns
    n_techs = len(names_list)
    df_ = pd.DataFrame(index=df_forecast.index, columns=df_forecast.columns)

    for j in range(n_techs):
        name = names_list[j]
        for i in range(year_make_forecast, end_comparison + 1):
            net_error = df_hist[name].loc[i] - df_forecast[name].loc[i]
            percent_err = 100.*(net_error)/df_hist[name].loc[i]
            df_.set_value(i, name, percent_err)

    return df_

def error_log_dif(df_hist, df_forecast, df_k, m, end_comparison=2015):
    '''Computes the error between the two dataframes and normalises with
    standard deviation giveb by df_k and number of points m
    Args:
        df_hist(DataFrame): data frame of true outcomes
        df_forecast(DataFrame): data frame of the forecasts for a given year
        df_k(DataFrame): data frame with standard deviation for each year
        m: number of data points considered for the normalisation
        end_comparison(int): year for which to stop comparing the data frames
    Returns:
        df_(DataFrame):data frame with the percentage error made for each year
        of prediction, starting for tau = 0.
    '''
    year_make_forecast = df_forecast.index[0]
    names_list = df_forecast.columns
    n_techs = len(names_list)
    df_ = pd.DataFrame(index=df_forecast.index, columns=df_forecast.columns)

    for j in range(n_techs):
        name = names_list[j]
        tau = 0
        k = df_k[name][0] #[0] is to set equal to value, not whole info of df
        for i in range(year_make_forecast, end_comparison + 1):
            net_error = np.log(df_hist[name].loc[i]) - \
                               np.log(df_forecast[name].loc[i])
            df_.set_value(i, name, net_error)
            tau += 1
    return df_

def normalise_error(e, k, tau, m):
    '''Normalises an error with the GRWD norm. Note that it allows for negative
    time horizons, in which case it only normalises by standard deviation.
    Args:
        e(float): error to normalise
        k(float): standar deviation of the data
        tau(int): forecast horizon
        m(int): number of points used for the forecast

    Returns:
        norm_e(float): error normalised with GRWD norm
    '''
    if tau <= 0:
        norm_e = e/k
    else:
        norm_e = e/(k * np.sqrt(tau + tau**2/m)  )
    return norm_e

def error_ktm(df_hist, df_forecast, df_k, m, end_comparison=2015):
    '''Computes the error between the two dataframes and normalises with
    standard deviation giveb by df_k and number of points m
    Args:
        df_hist(DataFrame): data frame of true outcomes
        df_forecast(DataFrame): data frame of the forecasts for a given year
        df_k(DataFrame): data frame with standard deviation for each year
        m: number of data points considered for the normalisation
        end_comparison(int): year for which to stop comparing the data frames
    Returns:
        df_(DataFrame):data frame with the percentage error made for each year
        of prediction, starting for tau = 0.
    '''
    year_make_forecast = df_forecast.index[0]
    names_list = df_forecast.columns
    n_techs = len(names_list)
    df_ = pd.DataFrame(index=df_forecast.index, columns=df_forecast.columns)

    for j in range(n_techs):
        name = names_list[j]
        tau = 0
        k = df_k[name][0] #[0] is to set equal to value, not whole info of df
        for i in range(year_make_forecast, end_comparison + 1):
            net_error = np.log(df_hist[name].loc[i]) - \
                               np.log(df_forecast[name].loc[i])
            ktm_error = normalise_error(net_error, k, tau, m)

            df_.set_value(i, name, ktm_error)

            tau += 1

    return df_


def error_forecasts_KTM(name, year_start, m, df_hist, df_expert, df_grwd, k, source = "AEOCap", t_lag = 3.):
    '''Computes the normalised error according to GRWD for a given technology according to historical data, both for expert forecast and GRWD. Note error are based on the logarithm of the values.
    Args:
        name(str): name of the technology for which to compute the forecast errors.
        year_start(int): year from which to start comparing errors.
        m(int): minimum number of data points needed before making the forecasts (for GRWD)
        df_hist(DataFrame): pandas dataframe with historical data
        df_expert(list): list of pandas dataframes, each with the expert forecast of a given year
        df_expert(list): list of pandas dataframes, each with the GRWD forecast of a given year
        k(float): standard deviation of the data used for forecast
        source(str): source of forecasts (Energy Power Sector or End-Use Sector)
        t_lag(float): difference in years between the year the forecast is made and the last year of available data

    Returns:
        mu (float): mean
        np.sqrt(k)(float): standard deviation
    '''
    if name == "Hydro":
        name2 = "Hydropower"
    elif name == "Municipal Waste" and source == "AEOGen":
        name2 = "Biogenic Municipal Waste"
    else:
        name2 = name

    l1 = np.log(df_hist[name]) #Note errors are based on the logarithm. This differs from the perentage errors.
    l2 = np.log(df_expert[name])
    l3 = np.log(df_grwd[name])
    tau = -t_lag + 1 #since we forecast since one year past the last year of data available but from t_lag years ahead. In other words "measuring" error implies negative forecast horizon. This must be treated in the norm parameter.
    Net_err_exp = []
    Net_err_grwd = []
    NormKTM_err_exp = []
    NormKTM_err_grwd = []
    # NOTE last year is defined here 2019
    for i in range(int(year_start - t_lag + 1), 2018):#2016): #year_start - t_lag + 1 is because we forecast since one year past the last year of data available.
        #print "i = ", year_start - t_lag + 1
        #print  l3.loc[i]
        net_error_exp = l1.loc[i] - l2.loc[i]
        net_error_grwd = l1.loc[i] - l3.loc[i]
        normktm_err_exp = normalise_error(net_error_exp, k, tau, m)
        normktm_err_grwd = normalise_error(net_error_grwd, k, tau, m)
        NormKTM_err_exp.append(normktm_err_exp)
        NormKTM_err_grwd.append(normktm_err_grwd)
        tau +=1

    return  NormKTM_err_exp, NormKTM_err_grwd

def write_errors(m, index_name_dict, error_name, error_function, df_hist, df_exp, df_grwd, df_k, errors_path, source, year_since_data_is_considered, t_lag ):
    '''Iterates over all technologies and  makes a csv file for each with the errors of the type specified
    Args:
        m(int): minimum number of data points needed before making the forecasts (for GRWD).
        index_name_dict(dictionary): dictionary with names of technologies and index in the data frames. This determines the years for which years we compute error.
        error_name(str): name tag for the csv file created
        error_function(function): function that compute the type of error desired
        df_hist(DataFrame): pandas dataframe with historical data
        df_expert(list): list of pandas dataframes, each with the expert forecast of a given year
        df_expert(list): list of pandas dataframes, each with the GRWD forecast of a given year
        df_k(DataFrame): list of pandas dataframes, each with  standard deviation of the given technology
        errors_path(str): path into which files are saved
        source (str): source of forecasts (Energy Power Sector or End-Use Sector)
        year_since_data_is_considered(int): year from which we use data to make forecast. Used to call and name the appropiate csv file.
        t_lag(float): difference in years between the year the forecast is made and the last year of available data

    Returns:
        None
    '''
    m = copy.deepcopy(m) #avoid overwriting

    for index in index_name_dict: #run through all years for which a forecast is made.
        y = index_name_dict[index]
        print(y)
        f_ex = open(errors_path + source+ "Expert"  +error_name + str(y) + "since_" + str(year_since_data_is_considered)+".csv", "w")
        f_ex.write(",")

        f_gr = open(errors_path + source+ "GRWD"  +error_name + str(y) + "since_" + str(year_since_data_is_considered)+".csv", "w")
        f_gr.write(",")

        # NOTE last year defined here
        for temp_y in range(int(y - t_lag + 1), 2018):#2016
            f_ex.write(str(temp_y) + ",")
            f_gr.write(str(temp_y) + ",")
        f_ex.write("\n")
        f_gr.write("\n")

        for nm in df_hist.columns[:]:
            f_ex.write(nm + ",")
            f_gr.write(nm + ",")

            k = float(df_k[index][nm][0])
            print(k)
            exp_err, grwd_err  = error_function(nm, y, m, df_hist, df_exp[index], df_grwd[index], k)

            for point in exp_err:
                f_ex.write(str(point)+ ",")
            f_ex.write("\n")

            for point in grwd_err:
                f_gr.write(str(point)+ ",")
            f_gr.write("\n")

        f_ex.close()
        f_gr.close()

    m += 1 #next forecast has one more data point

###############################################################################
#The plot function
###############################################################################
def plot_errors(names_list, df_error, alf=0.6, fig_error_path="fig/errors/",\
                source="EPS_Cap", name_fig="Error",\
                label_color_list = ['ro', 'bs', 'g^', 'k*', 'mp'], xlims=None,
                ylims=None, title = "Errors", y_lab = "error"):
    '''Plots the errors vs forecast horizon
    Args:
        names_lis(list of str): strings of technologies for which to do the plot
        df_error(DataFrame): pandas dataframe with the errors for each forecast horizon
        alf(float): transparency of points when plotting
        name_fig(str): name of figure to be exported
        label_color_list(list of str): color and market of scatter plot
        ylims(list): plot y limit
        title(str): title of the plot
        y_lab(str): plot y label
    '''
    n_years = len(df_error)
    n_techs = len(names_list)
    for j in range(n_techs):
        name = names_list[j]
        for i in range(n_years):
            if i == 0:
                #forecast_hor = [-2 + start + k for k in range(13 - i - start)]
                plt.plot( list(df_error[i].loc[name][:-1]), label_color_list[j], alpha = alf, label = name)
            else:
                #forecast_hor = [-2 + start + k for k in range(13 - i - start)]
                plt.plot(list(df_error[i].loc[name][:-1]),  label_color_list[j], alpha = alf)

    plt.xlabel("Forecast horizon")
    plt.ylabel(y_lab)
    plt.xlim(xlims)
    #plt.yticks([k*25 for k in range(-1,5)])
    plt.ylim(ylims)
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.grid()
    plt.title(title)
    plt.savefig(fig_error_path + source + "_" + name_fig + ".png", \
                bbox_inches='tight')
    plt.show()
def identity(x):
    return x

def squared(x):
    return x**2

def make_av_err_forcast_hor(names_list, df_error, start=0, func=identity):
    '''Computes the average error for each forecast horizon
    Args:
        names_lis(list of str): strings of technologies for to compute the
                                average error
        df_error(DataFrame): pandas dataframe with the errors for each
                            forecast horizon
        start(int): from which horizon to start. start = 0 give first error 0

    Returns:
        df_(DataFrame): pandas dataframe with the average error for each forecast horizon
    '''
    n_forecast_hor = len(df_error[0].columns) #- start #-1 stands for the unname column
    n_years = len(df_error)
    n_techs = len(names_list)
    df_ = pd.DataFrame(index=df_error[0].index, columns=[t for t in range(n_forecast_hor)])

    for j in range(n_techs):
        name = names_list[j]
        for t in range(n_forecast_hor):
            list_val = []
            for i in range(n_years):
                try: #errors since not all forecast horizons are met for all forecast years
                    if not np.isnan(df_error[i].loc[name][t]): #there are some nan where the full forecast horizon is not done (all years that are not the starting one)
                        list_val.append(func(df_error[i].loc[name][t]))
                except:
                    pass

            av_err = np.mean(list_val)
            df_.set_value(name, t, av_err)

    return df_

all_tech_markers =["co-", "m^-", "bp-", "gs-", "ro-", "ys-","k*-"]

def plot_average(df, markers = all_tech_markers, title="Average error", \
                 source= "EPS_Cap", name_fig="AveErr", \
                 fig_error_path = "fig/errors/",y_lab = "average normed error"):
    '''Plots the average error for each forecast horizon
    Args:
        df(DataFrame): dataframe with errors for each forecast horizon
        markers(list(str)): list of markers
    '''
    for i in range(len(df.index[:-1])):
        name = df.index[i]
        plt.plot(df.loc[name], markers[i], label = name)
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.ylabel(y_lab)
    plt.xlabel("Forecast horizon")
    plt.title(title)
    plt.savefig(fig_error_path + source + "_" + name_fig + ".png", \
                bbox_inches='tight')
    plt.show()


def plot_errors_distribution_all(names_list, df_error, ylims=None, title = "Errors", y_lab = "error" ):
    n_years = len(df_error)
    n_techs = len(names_list)
    list_errors = []
    for j in range(n_techs):
        name = names_list[j]
        for i in range(n_years):
            list_errors = list_errors +   list(df_error[i].loc[name])[3:-1] #3 so we exclude "measurement" errors, the -1 is for the last column of df which is nan
    hist_gr, bin_edges_gr = np.histogram(list_errors, bins = [ -10 + 0.5*i for i in range(40)], normed = True)
    plt.bar(bin_edges_gr[:-1], hist_gr, width = 0.5 ,  alpha=0.7, label = "GRWD", color = "b")
    Gaussian_list = [gaussian(i*0.01) for i in range(-400, 400)]
    Gaussian_points = [ i*0.01 for i in range(-400, 400) ]
    plt.plot(Gaussian_points,Gaussian_list, color = "g")
    #plt.hist(list_errors)
        #plt.xlabel("Forecast horizon")
        #plt.ylabel(y_lab)
        #plt.ylim(ylims)
    plt.title("Distribution of all technologies errors \n of the GRWD")
        #plt.savefig("figApril/Hist.pdf", bbox_inches='tight')
    plt.show()
