'''
AEO_data_from_excel_to_csv converts the excel files into csv files (each sheet to one file.)

Global variables:
    path(str): path to data folder
    sector(str): ElectricPower or End-Use
    projection_of(str): Generation Capacity or Generation
    name_expert_csv_files(str): file name where csv files are saved
    year_start(int): year for which we have the first AEOreport data
    year_end(int): year for which we have the last AEOreport data

R Maria del Rio-Chanona, Oxford, 2017
'''
import glob
import copy
import make_errors
from matplotlib import pylab as plt
import pandas as pd
import numpy as np

path = 'AEOData/'
sector = "ElectricPower"
projection_of = "Capacity"
expertForecastCapData = glob.glob(path + "/*" + projection_of + ".xls")
historicalCapData = glob.glob(path + "/*" + projection_of + "Historical.xls")
name_expert_csv_files = path + "AEOData"+ sector + projection_of
year_start = 2003
year_end = 2017 + 1 #+1 is because the for's in python are not inclusive

df_histAEOCap = pd.read_excel(historicalCapData[0])
df_histAEOCap.to_csv( historicalCapData[0][:-4] + ".csv", sep=',', encoding='utf-8')

historicalCapData[0][:-4]
df_check = []
for y in range(year_start, year_end):
    _df = pd.read_excel(expertForecastCapData[0], sheetname=str(y))
    df_check.append(_df)
    _df.to_csv( name_expert_csv_files + str(y) + ".csv", sep=',', encoding='utf-8')
