%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   ARIO_version_4_1.m ARIO version 4.1 model main loop
%    Copyright (C) 2007-2010 St�phane Hallegatte, M�t�o-France
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
%    Author: Stephane Hallegatte, hallegatte@centre-cired.fr
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Adaptive Regional Input-Ouput (ARIO) model by St�phane Hallegatte
%
%  Assess the economic cost of natural disasters
%  Simulate the reconstruction phase
%  Economy with N sectors
%  Applied on the Louisiana economy
%
%  changes of version 4.1 with respect to version 1.0
%  1- introduction of household budget and limited insurance penetration
%          i.e. households and companies pay a fraction of reconstruction
%          important: assumption of unlimited access to credit
%  2- household losses are included in the real estate sector
%          not treated separately (no more private reconstruction)
%  3- introduction of inventories (additional flexilibity and resilience),
%          changes in rationing rules (full proportionnal), reduced
%          production when inventories are insufficient
%  4- no price modeling in this version (no demand surge)
%  5- time step = 1 day
%
%  Structured as a function Res_VA = ARIO_version_4_1()
%  
%  Can also be called with parameters (to carry out senstivity analysis)
%
%  List of parameters: 
%    sens_ana = 1 if sensitivity analysis; 0 otherwise
%    ampl = multiplies the amount of direct losses by ampl with respect to
%               Katrina
%    maxmax_surcapa = maximum capacity for overproduction
%    tau_alpha = timescale for overproduction
%    NbJourStockU = nb of days of inventories for "normal" sectors
%    Tau_Stock = timescale of inventory restoration
%    Adj_prod = parameters for impact heterogeneity
%
%  Inputs: file 'Katrina_CBO_f' with the table Table_Katrina describing the disaster
%     'Table_Katrina' (N,N)
%       where Table_Katrina(i,j) is reconstruction demand by sector i to sector j
%
%  Output: Res_VA is a table (NStep+1,N) providing the value added by
%            each sector for a given day
%
%%%%%%%%%%%%%
%  Other needed input:
%  Inputs: File "Louisiana" with tables describing the local economy:
%     'T_Louis': total production per sector
%     'L_Louis': employment per sector
%     'IO_Table_Louis': Input-Ouput table (caution: the matrix is transposed in the code)
%                       this table includes only what is produced AND consumed in the region
%                       this table does not include housing services
%     'Imports_Louis': Imports per sector (i.e. imports from all sectors together, needed by each sector to produce)
%         (to produce T(i), the sector i needs to import a value Imports(i) of goods and services from all sectors)
%     'Exports_Louis': exports by each sector
%     'Local_Dem_Louis': local demand toward each sector
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Res_VA=ARIO_version_4_1_NO(sens_ana,ampl,maxmax_surcapa,tau_alpha,NbJourStockU,Tau_Stock,Adj_prod)

disp('*******************************************************************')
disp('Adaptive Regional Input-Ouput (ARIO) model by St�phane Hallegatte, version 4.1')
disp('Copyright (C) 2007-2009 St�phane Hallegatte and M�t�o-France')
disp('Applied on the Louisiana economy and the landfall of Katrina (2005)')
disp('*******************************************************************')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% MODEL PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
% IMPORTANT: the time step is ONE DAY
% All time unit are YEARS
% Economic fluxes are in Euro per Year
%%
% time step: one day
Dtime = 1/365.;
% simulation length
NStep=365.*10;
% number of sectors
N=15;
% create variables
OK=zeros(NStep+1,N);
OK_final=zeros(NStep+1,N);
actual_housing_loss = zeros(NStep+1,1);
actual_prod = zeros(NStep+1,1);
actual_Imports = zeros(NStep+1,N);
actual_Exports = zeros(NStep+1,N);
actual_Local_Dem = zeros(NStep+1,N);
actual_Dem_Exports = zeros(NStep+1,N);
actual_final_cons = zeros(NStep+1,N);
actual_Sales=zeros(NStep+1,N);
Final_Dem_Sat=zeros(NStep+1,N);
actual_L = zeros(NStep+1,N);
total_L=zeros(NStep+1);
avalanche = zeros(NStep+1,1);
Destr=zeros(N,1);
Rec_stock=zeros(NStep+1,N,N);
Debt=zeros(NStep+1);
prix = ones(NStep+1,N);
payback=zeros(NStep+1);
macro_effect=ones(NStep);
Dem_recon_t=zeros(NStep,N);
actual_reconstr = zeros(NStep+1,1);
old_actual_final_cons = zeros(NStep+1,N);
old_actual_recon_t = zeros(NStep,N);
Sales_tot=zeros(NStep+1,N);
Dem_reconstr = zeros(NStep+1,N,N);
Budget=zeros(1,NStep+1);
i=0;
j=0;
k=0;
year=0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% MODEL PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% if no parameters then no sensitivity analysis
if not(exist('sens_ana'))
    sens_ana = false;
end

% if no sensitivity analysis then reference parameters
if not(sens_ana) %
    % production over-capacity parameters
    maxmax_surcapa = 1.25*ones(1,N);
    tau_alpha = 1; % years
    % Nb of days of stock
    NbJourStockU = 90; % 60
    % timescale of stock building (year)
    Tau_Stock = 30/365.;
    % size of the direct losses
    ampl = 1;
    % parameter of production smoothing
    Adj_prod = .8;
end
% inventories
NbJourStock = NbJourStockU*ones(1,N);
% production smoothing parameter
Adj_produc=Adj_prod*ones(1,N);
% reconstruction timescale (in years)
tau_recon = 1/4;
% timescale of debt reimbursement (years)
tauR=2;
% epsilon used to estimate what is full recovery (in adaptation process)
epsilon=1.e-6;

if sens_ana % if sensitivity analysis then write parameters
    disp('Sensitivity analysis - Parameters:');
    [ampl,maxmax_surcapa(1),tau_alpha,NbJourStock(1),Tau_Stock,Adj_prod]
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ECONOMIC DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Household insurance penetration rate
penetration = 1.0;
% Business insurance penetration rate
penetrationf= 1.0 ;
%%%
% Household and transportation % non operational yet
% Total_Household = ?? ;
% Fact_Housing_Loss_Workers = ??;
%%%
% alpha = fraction of capital that is owned locally - ad hoc assumption, no data
% sources on Mumbai - used to know how decrease in business profit affects
% household income.
alpha = 0.5;
% wage = numeraire
wage = 1.;
%%%%%%%%%%%%%%%%%%%
load('Louisiana','ratio_K2Y','T_Louis','L_Louis','IO_Table_Louis','Imports_Louis','Exports_Louis','Local_Dem_Louis','Job_Louis');
exchange_rate = 1;
T = T_Louis*exchange_rate; % prod totale
L = L_Louis*exchange_rate; %
IO = IO_Table_Louis*exchange_rate;
Imports = Imports_Louis*exchange_rate;
Exports = Exports_Louis*exchange_rate;
Local_Dem = Local_Dem_Louis*exchange_rate;
% initial surcapacity situation % can be used to include a production gap
max_surcapa = ones(N,1)*1.0;
% Imports for consumption, assumed equal to local_dem
Imports_C = Local_Dem;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% INITIAL SITUATION (to check consistency and variable initialization)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Workers=zeros(NStep+1,N);
Produc=zeros(NStep+1,N);
Conso=zeros(N,1);
Sales=zeros(N,1);
Profit=zeros(NStep+1,N);
Prof_rate=zeros(NStep+1,N);
openness_rate=0.5;
for i=1:N
    Conso(i)=0;
    for j=1:N
        Conso(i)=Conso(i)+IO(j,i);
    end
    Sales(i)=0;
    for j=1:N
        Sales(i)=Sales(i)+IO(i,j);
    end
    % total sales to other industries in initial conditions
    Sales_ini(i)=Sales(i);
    % total production
    Produc(1,i)= Exports(i) + Local_Dem(i) + Sales(i);
    Long_Produc(1,i)=Produc(1,i);
    % sector profit
    Profit(1,i)= Produc(1,i) - (Conso(i)+wage*L(i)+Imports(i));
    % sector value added
    VA(1,i)=Produc(1,i) - Conso(i) - Imports(i);
    % Asset calculation
    Assets(i) = VA(1,i)*ratio_K2Y(i)*exchange_rate;
    % profit rate
    Prof_rate(1,i) = Profit(1,i)/T(i);
    % initial local demand
    Local_Dem_ini(i)=Local_Dem(i);
    Total_Local_Dem_ini=sum(Local_Dem_ini);
    % initial exports
    Exports_ini(i)=Exports(i);
    % final consumption
    actual_final_cons(1,i)=Local_Dem(i);
    % total production
    actual_prod(1)=sum(Produc(1,:));
end
% Profits from business outside the affected region
% Assumption 1: Profits that leave the region are equal to Profits that enter
% the region
Pi = (1-alpha)*sum(Profit(1,:));
% Assumption 2: Profit as needed to balance the local economy
Pi = sum(Local_Dem)+sum(Imports_C) - (sum(alpha*Profit(1,:))+sum(L));
% Initial household consumption and investment
% Assumption: Investments are made by households, not by businesses
DL_ini = wage*sum(L(:))+ alpha*sum(Profit(1,:)) + Pi;
% Alternative: DL_ini = wage*sum(L(:))+ (alpha*sum(Profit(1)) + Pi)*Redistr;
% where Redistr gives the amount of business profits that is redistributed
% to household. In this case, macro_effect must be modified, and the
% Final demand has to be modified to make a difference between business
% investment on the one hand, and household consumption and investment on
% the other hand.
% remember initial IO table
A_initial = IO;
% DELAY TO SUBSTITUTE THE PRODUCT OF THIS COMPANY WITH IMPORTS
% If =0 then, no substitution possible (e.g., electricity, water)
Sub_Del = zeros(N,1);
for i=1:N
    Sub_Del(i)=1;
    NoStock(i)=0;
end

% INVENTORIES FOR NON STOCKABLE GOODS & SERVICES
% Utilities
 NbJourStock_Short = 3.*NbJourStockU/60;
 NoStock(3)=1;
 NbJourStock(3)=NbJourStock_Short;
% Transportation
 NoStock(6)=1;
 NbJourStock(6)=NbJourStock_Short;
% Specifics of the construction sector 
 NbJourStock(4)=365*100000; % construction sector production is not urgent (in the IO table)
 
for i=1:N
    for j=1:N
        Stock(i,j) = IO(i,j)*NbJourStock(i)/365;        
        Long_ST(i,j) = Stock(i,j); 
        Order(i,j) = IO(i,j);
% if needed to be recorded
%        mem_Order(1,i,j)=Order(i,j);
%        mem_Stock(1,i,j)=Stock(i,j);
    end
end
disp('Economy data loaded');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% CREATION OF THE DISASTER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Katrina_CBO_small','Table_Katrina'); % already in euros !
for i=1:N+1
    for j=1:N
        Table_Dis_Louis(i,j)=Table_Katrina(i,j)*ampl;
    end
end
for i=1:N
    for j=1:N
        Dem_reconstr_ini(i,j)=Table_Dis_Louis(i,j);
    end
    Destr_capital_ini(i)=sum(Dem_reconstr_ini(i,:));
    Destr_ini(i)=Destr_capital_ini(i)/(ratio_K2Y(i)*VA(1,i));
    Destr(i)=Destr_ini(i);
    mem_Destr(1,i) = Destr(i);
end
disp('Disaster data loaded');

%%%%%%%%%%%%%%%%%
% if information needed
% disp(VA(1,:));
% disp(Assets);
% disp(Destr_capital_ini);
% disp(Destr_ini);
% disp(Destr_capital_ini);
%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PRODUCTION POST-DISASTER: ECONOMIC MODEL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialisation
for i=1:N
    OK(1,i)=1-Destr(i);
    for j=1:N
        Dem_reconstr(1,i,j)=Dem_reconstr_ini(i,j);
    end
end
actual_prod(1)=sum(Produc(1,:));
total_L(1)=sum(L);
for i=1:N
    actual_L(1,i)=L(i);
end
actual_Imports(1,:)=Imports;
actual_Exports(1,:)=Exports;
actual_Dem_Imports(1,:)=Imports;
actual_Local_Dem(1,:)=Local_Dem;
plus=zeros(N,N);
Order_prod = zeros(N,1);
Order_prod = Produc(1,:);
Demand = zeros(NStep+1,N);
Demand_total = zeros(NStep+1,N);
Demand(1,:) = Produc(1,:);
macro_effect(1) = 1;
Demand_total(1,:) = Produc(1,:);
Bascule=zeros(N,N);
Imp_sup=zeros(N,N);
cout = 0;
ini_profit = sum(Profit(1,:));
tot_profit=zeros(NStep+1,1);
tot_profit(1) = sum(Profit(1,:));
reconstr=zeros(NStep+1,N);
actual_recon_t=zeros(NStep, N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% loop on days (k=number of days)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Start simulation');
for k=1:NStep

    if (mod(k,365)==364) % every year
        disp(strcat('year:',int2str((k-1)/365),' completed'));
    end
    
    Conso=zeros(N,1);
    Sales=zeros(N,1);
    Produc_opt=zeros(NStep+1,N);
    
    %%%%%%%%%%%%%
    % OVERPRODUCTION MODELLING
    %%%%%%%%%%%%%
    if (k>1)
        % increase in production capacity
        for i=1:N
            if (OK_final(k,i)<(1-epsilon)) % if insufficient production two months in a row:
                % then production capacity increases to maximum production capacity with relaxation equation
                max_surcapa(i)=max_surcapa(i)+  Dtime/tau_alpha*(1-OK_final(k,i))*(maxmax_surcapa(i)-max_surcapa(i));
            end
            if (OK_final(k,i)>(1-epsilon)) % if sufficient production two months in a row:
                % then production capacity decreases to normal with relaxation equation
                max_surcapa(i)=max_surcapa(i)+(1-max_surcapa(i))*Dtime/tau_alpha; % back to normal = 12 months
            end
        end
    end
    mem_surcapa(k+1,:)=max_surcapa(:);
    %%%%%%%%%%%%%
    % END OVERPRODUCTION
    %%%%%%%%%%%%%

    % calculation of demand as a function of budget
    for i=1:N
        % reduction in local demand by macro_effect
        actual_Local_Dem(k+1,i) = macro_effect(k)*Local_Dem(i);
        actual_Imports_C(i)= macro_effect(k)*Imports_C(i);
        % unchanged exports
        actual_Exports(k+1,i) = Exports(i);
        % demand for reconstruction by households does not depend on budget
        % IMPORTANT (i.e., perfect access to credit for reconstruction)
        Dem_recon_t(k,i)= 0;
        % rest of reconstruction demand (from businesses)
        for j=1:N
            % demand from reconstruction unit #j to #i
            Dem_recon_t(k,i) = Dem_recon_t(k,i) + Dem_reconstr(k,j,i); % normal situation: over one year
        end
        actual_recon_t(k+1,i)= Dem_recon_t(k,i)/tau_recon;        
        mem_dem_recon(k+1,i)=actual_recon_t(k+1,i);
        mem_dem_export(k+1,i)= actual_Exports(k+1,i);
        mem_dem_local(k+1,i) = actual_Local_Dem(k+1,i);
        % Demand_total = sum of all demands
        Demand_total(k+1,i)= Exports(i) + actual_Local_Dem(k+1,i) + actual_recon_t(k+1,i);
        if (Demand_total(k+1,i)==0)
            Demand_total(k+1,i)=1e-6;
        end
    end
    % intermediate consumption Order(i,j) = order of j to i
    for i=1:N
        mem_tot_order(k+1,i)=0;
        for j=1:N
            Demand_total(k+1,i)=Demand_total(k+1,i)+Order(i,j);
            mem_tot_order(k+1,i)=mem_tot_order(k+1,i)+Order(i,j);            
        end
        Produc(k+1,i)=Demand_total(k+1,i);
        mem_demand_total(k+1,i)=Demand_total(k+1,i);        
    end 
    % loop on all sector to assess production limits (production capacity)
    for i=1:N
        % maximum production in the sector
        max_prod(i) = max(0,max_surcapa(i)*Produc(1,i)*(1-Destr(i)));
        % if production without constraint is larger than max
        % production, then production equals max prod
        if (Produc(k+1,i)>max_prod(i))
            Produc(k+1,i) = max_prod(i); % production is bounded by maximum production
        end
        OK_final(k+1,i)=min(1,Produc(k+1,i)/Demand_total(k+1,i));        
    end
    % limits due to insufficient stocks / Stock(i,j)=stock of goods i
    % owned by j
    for j=1:N
        for i=1:N
            % needed stocks drive production decision (required stock in
            % the paper)
            Needed_Stock(i,j) = Produc(k+1,j)/Produc(1,j)*IO(i,j)*NbJourStock(i)/365; 
            %  mem_Needed_Stock(k+1,i,j) = Needed_Stock(i,j);
        end
        for i=1:N
            if (Needed_Stock(i,j)==0)
                out_sec(i)=1.;
                out_sec2(i)=1.;
            else
                if Stock(i,j)<(Adj_produc(i)*Needed_Stock(i,j))
                    out_sec(i) = max(0,(1 - (Adj_produc(i)*Needed_Stock(i,j)-Stock(i,j))/(Adj_produc(i)*Needed_Stock(i,j))));
                else
                    out_sec(i)=1.;
                end
                out_sec2(i) = (1 - (Adj_produc(i)*Needed_Stock(i,j)-Stock(i,j))/(Adj_produc(i)*Needed_Stock(i,j)));
            end
        end
        [mem_out_sec(k+1,j) mem_qui_out_sec(k+1,j)]=min(out_sec2);        
        mem_out_sec(k+1,j)=mem_out_sec(k+1,j)*Produc(k+1,j);
        mem_out_sec(k+1,j)=min(out_sec)*Produc(k+1,j);        
        Produc(k+1,j)=Produc(k+1,j)*min(out_sec);       
    end

    % Satisfied demands
    % new rationing scheme: full proportional (final demand and
    % interindustry demands)
    for i=1:N
        actual_recon_t(k+1,i) = actual_recon_t(k+1,i)*(Produc(k+1,i)/Demand_total(k+1,i));
        actual_Exports(k+1,i)= actual_Exports(k+1,i)*(Produc(k+1,i)/Demand_total(k+1,i));
        actual_final_cons(k+1,i)= actual_Local_Dem(k+1,i)*(Produc(k+1,i)/Demand_total(k+1,i));
        for j=1:N
            Supply(i,j) = Order(i,j)*(Produc(k+1,i)/Demand_total(k+1,i));
        end
        % underproduction with respect to demand
        Final_Dem_Sat(k+1,i)= (Produc(k+1,i) - Demand_total(k+1,i)) ;
    end

    % Stock dynamics (Stock(i,j) = stock of goods i own by sector j)
    for i=1:N
        for j=1:N
            Stock(i,j)=max(epsilon,Stock(i,j) - Dtime*Produc(k+1,j)/Produc(1,j)*IO(i,j) + Dtime*Supply(i,j));
        end
    end

    % New Orders
    for i=1:N
        for j=1:N               
            Stock_target(i,j) = min(Demand_total(k+1,j),max_prod(j))/Produc(1,j)*IO(i,j)*NbJourStock(i)/365;            
            % introduction of smoothing to reduce numerical instabilities
            tau_stock_target = 60./365.;
            Long_ST(i,j) = Long_ST(i,j) + Dtime/tau_stock_target*(Stock_target(i,j) - Long_ST(i,j)); % TEST
            % Order by j to i
            Order(i,j) = max(epsilon,Produc(k+1,j)/Produc(1,j)*IO(i,j) + (Long_ST(i,j)-Stock(i,j))/(Tau_Stock*NbJourStock(i)/NbJourStockU));                                   
% if need to be recorded
%            mem_Order(k+1,i,j)=Order(i,j);
%            mem_Stock(k,i,j)=Stock(i,j);
%            mem_Needed_Stock(k,i,j)=Needed_Stock(i,j);
%            mem_Stock_target(k,i,j)=Stock_target(i,j);
        end
    end

    for i=1:N
        % cost of intermediate consumption and imports
        Conso(i)=0;
        actual_Imports(k+1,i) = Imports(i)*Produc(k+1,i)/Produc(1,i);
        VA(k+1,i)=Produc(k+1,i) - actual_Imports(k+1,i);
        for j=1:N
            if (IO(j,i)>0)
                % value added in sector i (month k+1)
                VA(k+1,i)=VA(k+1,i) - IO(j,i)*Produc(k+1,i)/Produc(1,i);
                % Conso(i) = sum of purchase from sector i
                Conso(i)=Conso(i)+prix(k+1,j)*IO(j,i)*Produc(k+1,i)/Produc(1,i);
            end
        end

        actual_W(k+1,i)=Job_Louis(i)*VA(k+1,i)/VA(1,i); % IMPORTANT: hiring always possible
        actual_L(k+1,i)=L(i)*Produc(k+1,i)/Produc(1,i); % IMPORTANT: hiring always possible
        % profits reduced by reconstruction spending (as a function of
        % insurance penetration) (warning: unchanged prices)
        Profit(k+1,i)= Produc(k+1,i) - (Conso(i)+actual_L(k+1,i)+ actual_Imports(k+1,i))- reconstr(k,i)*(1-penetrationf);
        tot_profit(k+1) = sum(Profit(k+1,:));
        Prof_rate(k+1,i) = Profit(k+1,i)/T(i);
    end

    % total consumed labor
    total_L(k+1)=0;
    for i=1:N
        total_L(k+1) = total_L(k+1)+ actual_L(k+1,i);
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % RECONSTRUCTION MODELLING
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:N
        % Reconstruction of unit #i
        if (Destr(i)>0)
            % reconstruction by unit #j
            for j=1:N
                if (Produc(k+1,j)>0)&(Dem_reconstr(k,i,j)>0) % otherwise, no reconstruction
                    Dem_reconstr(k+1,i,j)= max(0,Dem_reconstr(k,i,j) - Dtime*actual_recon_t(k+1,j)*(Dem_reconstr(k,i,j))/Dem_recon_t(k,j) );
                    cout = cout + prix(k+1,j)*Dtime*actual_recon_t(k+1,j);
                end
            end
            reconstr(k+1,i)=max(0,sum(Dem_reconstr(k,i,:)) - sum (Dem_reconstr(k+1,i,:)));
        end
        % new production capacity in sector i, as a function of
        % reconstruction needs and total capital amount
        Destr(i)=sum(Dem_reconstr(k+1,i,:))/(Assets(i));
        mem_Destr(k+1,i) = Destr(i);
    end
    actual_prod(k+1)=sum(Produc(k+1,:));
    t = 0;
    %%%%%%%%%%%%%
    % HOUSEHOLD BUDGET MODELING
    %%%%%%%%%%%%%
    % reduction in consumption by macro_effect is budget is reduced
    Budget(k+1) = Budget(k)+ ((wage*sum(actual_L(k,:))+ alpha * tot_profit(k) + Pi) - sum(actual_Imports_C)- sum(actual_final_cons(k,:)))/12 - (1-penetration)*actual_reconstr(k);
    rec_actual_Imports_C(k+1,:)=actual_Imports_C;
    macro_effect(k+1) = (DL_ini + 12*1/tauR * Budget(k+1))/DL_ini;
    mem_local_dem(k,:)=Local_Dem(:);
end % of loop time

% production per quarter (smooth the results, which are sometimes noisy for numerical reasons)
Dtime = 1/365.;
LengthMonth = floor(3.*30./365./Dtime)+1;
NQu=floor(NStep*Dtime*4.);
VA_q=zeros(NQu,N);
for k=1:NQu
    for n=1:N
        VA_q(k,n)=0;
    end
    for l=1:LengthMonth
        for n=1:N
            VA_q(k,n)=VA_q(k,n)+1./LengthMonth*VA((k-1)*LengthMonth+l,n);
        end
    end
end

% relative VA 
for i=1:NStep+1
    for j=1:N
        VA_rel(i,j) = VA(i,j)/VA(1,j);
    end
end
VA2004s = (365)*VA(1,:)
VA2005s = sum(VA(1:120,:))+(365-120)*VA(1,:);
VA2006s = sum(VA(121:485,:));
D0504 = (sum(VA2005s) - sum(VA2004s))./sum(VA2004s)*100;
D0604 = (sum(VA2006s) - sum(VA2004s))./sum(VA2004s)*100;

% Print a few results
disp('Total direct losses (million)')
disp(sum(sum(Table_Dis_Louis(:,:))))
totaldirect=sum(sum(Table_Dis_Louis(:,:)))+1;

disp('Total VA Losses (absolute, million, <0 is losses, >0 is gains)')
disp((sum(sum(VA)) - (NStep+1)*sum(VA(1,:)))/365.)
total=-(sum(sum(VA)) - (NStep+1)*sum(VA(1,:)))/365 ;
totalratio=total/totaldirect;

disp('Total VA Losses (relative, %, <0 is losses, >0 is gains)')
disp((((sum(sum(VA)) - (NStep+1)*sum(VA(1,:)))/365.)/(sum(VA(1,:))))*100)

disp('Per sector VA losses (absolute, million USD, >0 is losses, <0 is gains)')
disp((sum(VA) - (NStep+1)*(VA(1,:)))/365.)

disp('growth 2005 vs 2004');
disp(D0504);
disp('growth 2006 vs 2004');
disp(D0604);

%CREATE FIGURE
if not(sens_ana)
    figure1 = figure('PaperPosition',[0.6345 6.345 20.3 15.23],'PaperSize',[20.98 29.68]);
    %% Create axes
    axes1 = axes('FontSize',12,'Parent',figure1);
    xlim(axes1,[0 10]);
    xlabel(axes1,'Time (years)');
    ylabel(axes1,'Change in VA (%)');
    box(axes1,'on');
    hold(axes1,'all');
    Ref=sum(VA(1,:));
    x1=1:3651;
    y1=(sum(VA')/Ref-1)*100;
    plot1 = plot(...
        x1/365,y1,...
        'LineStyle','--',...
        'LineWidth',2,...
        'Parent',axes1);
end

% save results
% different types of results can be saved
%save('Results.mat','actual_Exports','actual_Local_Dem','mem_IO','mem_dem_recon','mem_dem_export','mem_dem_local','mem_tot_order','mem_demand_total','mem_out_sec','mem_qui_out_sec','actual_W','mem_Needed_Stock','mem_surcapa','actual_L','mem_Destr','mem_Order','rec_actual_Imports_C','actual_recon_t','actual_Local_Dem','actual_reconstr','macro_effect','actual_final_cons','tot_profit','VA','VA_q','VA_rel','Final_Dem_Sat','Demand_total','Debt','payback','Budget','Dem_reconstr', 'Produc','prix','OK','IO','OK_final','mem_local_dem','mem_Stock','Order','Supply')
%save('Results.mat','actual_Exports','actual_Local_Dem','mem_dem_recon','mem_dem_export','mem_dem_local','mem_tot_order','mem_demand_total','mem_out_sec','mem_qui_out_sec','actual_W','mem_surcapa','actual_L','mem_Destr','rec_actual_Imports_C','actual_recon_t','actual_Local_Dem','actual_reconstr','macro_effect','actual_final_cons','tot_profit','VA','VA_q','VA_rel','Final_Dem_Sat','Demand_total','Debt','payback','Budget','Dem_reconstr', 'Produc','prix','OK','IO','OK_final','mem_local_dem','Order','Supply')
save('Results.mat','mem_out_sec','mem_qui_out_sec','mem_surcapa','mem_Destr','VA','VA_q','VA_rel','Final_Dem_Sat','Demand_total','Produc');
disp('Results saved in file "Results.mat"');
Res_VA=VA;
end

